package com.student.Student_Enrollment_System.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.student.Student_Enrollment_System.dto.Student;
import com.student.Student_Enrollment_System.repository.StudentRepository;

@Repository
public class StudentDao {

	@Autowired
	private StudentRepository studentRepository;
	
	
	public Student saveStudent(Student student)
	{
		return studentRepository.save(student);
	}
	
	
	public List<Student> getAllStudents()
	{
		return studentRepository.findAll();
	}
	
	
	public Student getStudent(int id)
	{
		Optional<Student> s= studentRepository.findById(id);
		if(s.isPresent())
		{
			return s.get();
		}
		return null;
	}

	
	public Optional<Student> findStudent(int id)
	{
		return studentRepository.findById(id);
	}
	
	
	
	public Student updateStudent(Student student)
	{
		return studentRepository.save(student);
	}
	
	
	public void deleteStudent(int id)
	{
		studentRepository.deleteById(id);
	}

}
