package com.student.Student_Enrollment_System.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.student.Student_Enrollment_System.dao.StudentDao;
import com.student.Student_Enrollment_System.dto.Student;

@Service
public class StudentService {

	
	@Autowired
	private StudentDao studentDao;
	
	
	
	public Student saveStudent(Student student)
	{
		return studentDao.saveStudent(student);
	}
	
	
	public List<Student> getAllStudents()
	{
		return studentDao.getAllStudents();
	}
	
	
	public Student getStudent(int id)
	{
		return studentDao.getStudent(id);
	}
	
	
	public Student updateStudent(Student student)
	{
		return studentDao.updateStudent(student);
	}
	
	
	public void deleteStudent(int id)
	{ 
		studentDao.deleteStudent(id);
	}

}
