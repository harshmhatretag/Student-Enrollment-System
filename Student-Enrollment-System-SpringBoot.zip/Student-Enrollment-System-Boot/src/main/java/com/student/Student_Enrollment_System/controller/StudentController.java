package com.student.Student_Enrollment_System.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.student.Student_Enrollment_System.dto.Student;
import com.student.Student_Enrollment_System.service.StudentService;

import jakarta.servlet.http.HttpSession;


@Controller
@RequestMapping("/student")
public class StudentController {

	@Autowired
	private StudentService studentService;
	
	
	@GetMapping
	public String home(Model m)
	{
		List<Student> student= studentService.getAllStudents();
		m.addAttribute("std",student);
		
		return "home.html";
	}
	
	
	@GetMapping("/addStudent")
	public String addStudent()
	{
		return "addStudent.html";
	}
	
	
	@PostMapping("/saveStudent")
	public String saveStudent(@ModelAttribute Student student, HttpSession session)
	{
		studentService.saveStudent(student);
		session.setAttribute("msg", "Student Added Sucessfully");
		return "sucess.html";
	}
	
	
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable int id, Model m)
	{
		Student s= studentService.getStudent(id);
		m.addAttribute("std", s);
		return "edit.html";
	}
	
	
	@PostMapping("/update")
	public String updateStudent(@ModelAttribute Student student, HttpSession session)
	{
		studentService.updateStudent(student);
		session.setAttribute("msg", "Student Data Updated Sucessfully");
		return "update.html";
	}
	
	
	
	@GetMapping("/delete/{id}")
	public String deleteStudent(@PathVariable int id, HttpSession session)
	{
		studentService.deleteStudent(id);
		session.setAttribute("msg", "Student Deleted Sucessfully");
		return "delete.html";
	}
	
}
